
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'I2S_Codec_PDMA' 
 * Target:  'I2S_Codec_PDMA' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "M55M1.h"



#endif /* RTE_COMPONENTS_H */
